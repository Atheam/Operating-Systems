#################################################
W celu uruchomienia wersji programu bez testow czasowych nalezy uzyc 
komedy 
make run-lib
lub
make run-sys
W celu urucomienia programu z testami czasowymi nalezy uzyc 

make timeit

###################################################
